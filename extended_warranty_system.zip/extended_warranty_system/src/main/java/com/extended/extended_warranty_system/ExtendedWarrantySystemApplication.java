package com.extended.extended_warranty_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtendedWarrantySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtendedWarrantySystemApplication.class, args);
	}

}
